﻿/// <summary>
/// The Helpers namespace.
/// </summary>
namespace RM.Common.Helpers
{
    public class AppSettings
    {
        public string Secret { get; set; }
    }
}
