﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RM.Common
{
    /// <summary>
    /// Class ConstString.
    /// </summary>
    public static class ConstString
    {
        /// <summary>
        /// The secret
        /// </summary>
        public const string Secret = "RXN0byBlcyB1bmEgcHJ1ZWJhIHBhcmEgdmVyIGNvbW8gamFsYSBsYSBlbmNyaXB0YWNpb24gZGVsIHRva2VuIG11amFqYWphag==";
    }
}
