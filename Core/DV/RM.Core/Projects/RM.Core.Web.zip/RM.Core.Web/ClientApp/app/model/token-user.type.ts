﻿export class TokenUser {
    Id: number;
    UserName: string;
    Name: string;
    Token: string;
}