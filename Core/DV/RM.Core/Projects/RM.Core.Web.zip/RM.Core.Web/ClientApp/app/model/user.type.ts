﻿export class User {
    Id : number;
    CompanyId : number;
    TypeId : number;
    UserName : string;
    UserMiddleName : string;
    UserLastName : string;
    UserMotherName : string;
    Email : string;
    PassWord : string;
    PassWordSalt : string;
    Active : boolean;
}